
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Calendar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author handsomedad
 */
public class ScheduleQueries {
    private static PreparedStatement addScheduleEntry;
    private static PreparedStatement getScheduleByStudent;
    private static PreparedStatement getScheduledStudentCount;
    private static Connection connection;
    private static ResultSet resultset;
    private static int count;
   
    public static void addScheduleEntry(ScheduleEntry entry){
        connection = DBConnection.getConnection();
        
        try{
            java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());

            addScheduleEntry = connection.prepareStatement("insert into app.schedule (Semester, CourseCode, StudentID, Status, Timestamp) values (?, ?, ?, ?, ?)");
            addScheduleEntry.setString(1, entry.getSemester());
            addScheduleEntry.setString(2, entry.getCourseCode());
            addScheduleEntry.setString(3, entry.getStudentID());
            addScheduleEntry.setString(4, entry.getStatus());
            addScheduleEntry.setTimestamp(5, currentTimestamp);
            addScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
    
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID){
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> scheduleEntry = new ArrayList<>();
        
        try{
            
            addScheduleEntry = connection.prepareStatement("select * from app.schedule where Semester = ? and StudentID = ?");
            addScheduleEntry.setString(1, semester);
            addScheduleEntry.setString(2, studentID);
            resultset = addScheduleEntry.executeQuery();
            while (resultset.next()){
                ScheduleEntry element = new ScheduleEntry(resultset.getString(1),resultset.getString(2),resultset.getString(3),resultset.getString(4),resultset.getTimestamp(5));
                scheduleEntry.add(element);
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return scheduleEntry;
    }
    
    public static int getScheduledStudentCount(String currentSemester, String courseCode){
        connection = DBConnection.getConnection();
        
        try{
            getScheduledStudentCount = connection.prepareStatement("select count(StudentID) from app.schedule where Semester = ? and courseCode = ?");
            getScheduledStudentCount.setString(1, currentSemester);
            getScheduledStudentCount.setString(2, courseCode);
            resultset = getScheduledStudentCount.executeQuery();
            resultset.next();
            count = resultset.getInt(1);
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return count;
    }
}


